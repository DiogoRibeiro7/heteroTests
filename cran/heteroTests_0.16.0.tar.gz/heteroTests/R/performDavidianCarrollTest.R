#' Perform Davidian–Carroll test for heteroscedasticity
#'
#' Fits a polynomial regression of the log-squared residuals on the fitted values
#' to detect parametric variance functions, as proposed by Davidian and Carroll
#' (1987).
#'
#' @param model A fitted [stats::lm] object providing residuals and fitted values
#'   for the auxiliary regression.
#' @param data Optional data frame the model was fitted to. When `NULL`, the
#'   default, the model frame of `model` is used. The statistic is computed
#'   from the residuals and fitted values of `model`, so `data` does not change
#'   the result; it is accepted so that every test takes `(model, data, ...)`.
#' @param degree Positive integer specifying the polynomial degree used for the
#'   fitted values (default `2`). Higher degrees allow more flexible variance
#'   functions but require larger samples. Before 0.15.0 `degree` was the
#'   second argument: a number passed there by position is still read as
#'   `degree`, with a warning that shows the new call; that form stops working
#'   in 1.0.0.
#'
#' @return An object of class \code{htest} with the F statistic, numerator and
#'   denominator degrees of freedom, and p-value for the joint null of constant
#'   variance.
#'
#' @details
#' The auxiliary regression
#' \deqn{\log \hat{e}_i^2 = \gamma_0 + \gamma_1 \hat{y}_i + \cdots + \gamma_p
#'   \hat{y}_i^p + u_i}
#' models the log-variance as a polynomial in the fitted values. The test evaluates
#' \eqn{\gamma_1 = \cdots = \gamma_p = 0} using an F statistic with \eqn{p}
#' numerator degrees of freedom. Significant results indicate that the variance can
#' be described by a smooth function of the mean, which can guide variance-stabilising
#' transformations or weighted least squares specifications.
#'
#' The function validates that `degree` is a positive integer, that the model
#' supplies sufficient observations relative to `degree`, and that residuals display
#' non-trivial variation before fitting the auxiliary regression.
#'
#' @references
#' Davidian, M., & Carroll, R. J. (1987). Variance function estimation. *Journal of
#' the American Statistical Association, 82*(400), 1079–1091.
#'
#' Carroll, R. J., & Ruppert, D. (1988). *Transformation and Weighting in Regression*.
#' Chapman & Hall. Chapter 3 discusses variance-function diagnostics.
#'
#' @examples
#' data(mtcars)
#' mod <- lm(mpg ~ wt + qsec, data = mtcars)
#' performDavidianCarrollTest(mod)
#'
#' # Higher-order polynomial
#' performDavidianCarrollTest(mod, degree = 3)
#'
#' # Simulated heteroscedastic data with exponential variance in the mean
#' set.seed(246)
#' x <- runif(160)
#' y <- 1 + x + rnorm(160, sd = exp(0.5 * x))
#' performDavidianCarrollTest(lm(y ~ x))
#'
#' @seealso
#' [performHarveyTest()] and [performNCVTest()] for related
#' variance-function diagnostics.
performDavidianCarrollTest <- function(model, data = NULL, degree = 2) {
  rrefuse_non_gaussian_glm(model, "performDavidianCarrollTest")
  if (is.numeric(data) && is.null(dim(data)) && missing(degree)) {
    rwarn_positional_call(
      "performDavidianCarrollTest", substitute(model), list(degree = substitute(data))
    )
    degree <- data
    data <- NULL
  }
  # The model context (R/model_context.R) refuses a model frame that
  # `model = FALSE` rebuilt from data changed after the fit. The test reads
  # nothing from `data`, which is matched to the observations of the fit as by
  # every test built on the context (decision 31).
  rcheck_data_argument(data, "performDavidianCarrollTest")
  ctx <- rmodel_context(model, data, fn = "performDavidianCarrollTest",
                        test_label = "Davidian-Carroll")
  if (!inherits(model, "lm")) {
    stop("`model` must be an object of class 'lm'.")
  }
  rrefuse_nonfinite_coefficients(model, "Davidian-Carroll test", allow_aliased = TRUE)
  rvalidate_model_context(ctx)
  if (!is.numeric(degree) || degree < 1) {
    stop("`degree` must be a positive integer.")
  }

  res <- rpearson_residuals(model)
  fit <- fitted(model)
  # Under na.action = na.exclude both vectors are padded back to the original
  # row count with NA placeholders, which made var(fit) NA and turned the
  # guard below into "missing value where TRUE/FALSE needed". Test the rows
  # the model actually fitted.
  complete <- !is.na(res) & !is.na(fit)
  res <- res[complete]
  fit <- fit[complete]
  if (stats::var(fit) <= .Machine$double.eps) {
    stop("Davidian-Carroll test requires variability in fitted values.", call. = FALSE)
  }
  # A residual of exactly zero sends log(e^2) to -Inf and the auxiliary fit
  # fails with 'NA/NaN/Inf in y'. Floor it and warn, as the other
  # log-variance diagnostics do.
  log_e2 <- rlog_squared_residuals(res, "Davidian-Carroll test")
  df <- data.frame(log_e2 = log_e2, fit = fit)
  formula_str <- paste0("log_e2 ~ poly(fit, ", degree, ")")
  aux_model <- lm(stats::as.formula(formula_str), data = df)
  aov_table <- anova(aux_model)
  F_stat <- aov_table$`F value`[1]
  df_num <- aov_table$Df[1]
  df_den <- aov_table$Df[2]
  p_value <- aov_table$`Pr(>F)`[1]

  structure(
    list(
      statistic = c(F = F_stat),
      parameter = c(df1 = df_num, df2 = df_den),
      p.value = p_value,
      method = "Davidian-Carroll test",
      data.name = deparse(formula(model))
    ),
    class = "htest"
  )
}
