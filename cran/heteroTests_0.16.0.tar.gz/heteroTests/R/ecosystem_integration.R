#' Ecosystem integration helpers
#'
#' These utilities extend the package to work smoothly with broader R
#' ecosystem tools such as tidymodels workflows, parsnip model objects,
#' `survey` designs, data.table-backed pipelines and broom tidiers. They are
#' exported only where user interaction is expected; internal helpers remain
#' undocumented.
#'
#' @keywords internal
".ht_null" <- NULL

# Single canonical definition shared with intelligent_recommendations.R; both
# copies must stay identical so package collation order cannot change behaviour.
`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0L) {
    return(y)
  }
  if (is.atomic(x) && length(x) == 1L && is.na(x)) {
    return(y)
  }
  x
}

# internal ---------------------------------------------------------------

.ht_prepare_input_data <- function(data, context = "diagnostic") {
  if (is.null(data)) {
    return(list(
      data = NULL,
      grouped = FALSE,
      group_splits = NULL,
      group_keys = NULL,
      source = "unknown"
    ))
  }

  allowed_classes <- c("data.frame", "tbl_df", "data.table", "grouped_df", "dtplyr_step", "survey.design")
  if (!any(vapply(allowed_classes, inherits, logical(1), x = data))) {
    stop("`data` must be a data.frame or a compatible tibble/data.table object.", call. = FALSE)
  }

  if (inherits(data, "dtplyr_step")) {
    if (!requireNamespace("dtplyr", quietly = TRUE) || !requireNamespace("dplyr", quietly = TRUE)) {
      stop(
        sprintf(
          "dtplyr input supplied to %s but packages `dtplyr` and `dplyr` are not installed.",
          context
        ),
        call. = FALSE
      )
    }
    data <- dplyr::collect(data)
  }

  source <- class(data)[1]

  if (inherits(data, "grouped_df")) {
    if (!requireNamespace("dplyr", quietly = TRUE)) {
      stop(
        sprintf(
          "Grouped tibble supplied to %s but package `dplyr` is not installed.",
          context
        ),
        call. = FALSE
      )
    }
    group_keys <- dplyr::group_keys(data)
    splits <- dplyr::group_split(data, .keep = TRUE)
    splits <- lapply(splits, function(df) {
      df <- dplyr::ungroup(df)
      as.data.frame(df)
    })
    data <- as.data.frame(dplyr::ungroup(data))
    grouped <- TRUE
  } else {
    group_keys <- NULL
    splits <- NULL
    grouped <- FALSE
  }

  if (inherits(data, "data.table")) {
    data <- as.data.frame(data)
  }

  if (!is.data.frame(data)) {
    data <- as.data.frame(data)
  }

  list(
    data = data,
    grouped = grouped,
    group_splits = splits,
    group_keys = group_keys,
    source = source
  )
}

.ht_extract_formula <- function(model) {
  if (inherits(model, "formula")) {
    return(model)
  }
  fm <- tryCatch(stats::formula(model), error = function(e) NULL)
  if (!is.null(fm)) {
    return(fm)
  }
  call <- tryCatch(model$call, error = function(e) NULL)
  if (!is.null(call) && "formula" %in% names(call)) {
    return(eval(call$formula, envir = parent.frame()))
  }
  NULL
}

# Refit a fitted lm/glm on another data frame by evaluating its own call again,
# so the family, weights, offset, subset and na.action are the ones the model
# was fitted with. Passing those to stats::lm() as local variables does not
# work: lm() looks them up in `data` and then in the environment of the formula,
# never in the function that calls it.
.ht_refit_model <- function(model, data) {
  call <- tryCatch(stats::getCall(model), error = function(e) NULL)
  formula <- .ht_extract_formula(model)
  if (!is.call(call) || is.null(formula)) {
    stop(
      "The fitted model does not record the call that produced it, so it ",
      "cannot be refitted on other data.",
      call. = FALSE
    )
  }
  call$formula <- formula
  call$data <- quote(.ht_refit_data)
  enclosure <- environment(formula)
  if (!is.environment(enclosure)) {
    enclosure <- globalenv()
  }
  env <- new.env(parent = enclosure)
  env$.ht_refit_data <- data
  eval(call, env)
}

# The same, for one group of a grouped analysis. A model whose weights, offset
# or subset are vectors in the workspace cannot be split by group, and lm()
# reports that as a length mismatch; say what it means.
.ht_refit_group <- function(model, data) {
  tryCatch(
    .ht_refit_model(model, data),
    error = function(e) {
      stop(
        "The model could not be refitted within a group: ",
        conditionMessage(e), "\n",
        "Grouped diagnostics evaluate the model's own call on each group, so ",
        "every variable it uses, including weights, offset and subset, must ",
        "be a column of `data`.",
        call. = FALSE
      )
    }
  )
}

# What a survey design gets: an ordinary least-squares fit to its data. The
# diagnostics have no design-based version, and the alternatives that look
# like one are worse. Sampling weights are not precision weights, so a fit by
# lm(weights = ) or survey::svyglm(), whose residuals() carry the square roots
# of the weights, makes every test reject a homoscedastic model whenever the
# weights vary with the regressors. inst/validation/survey-designs-size.R has
# the measurements.
.ht_survey_ols <- function(formula, design, context) {
  data <- as.data.frame(design$variables)
  ignored <- .ht_survey_ignored_features(design)
  if (length(ignored) > 0L) {
    warning(
      context, " does not use the ", paste(ignored, collapse = " or "),
      " of the survey design. The model is fitted by ordinary least squares ",
      "and the tests treat the observations as an independent sample, so ",
      "they hold their level only if the design can be ignored given the ",
      "regressors. See ?runSurveyHeteroTests.",
      call. = FALSE
    )
  }
  list(model = stats::lm(formula, data = data), data = data)
}

# The parts of a design the classical tests cannot see: unequal weights, and
# sampling units that hold more than one observation.
.ht_survey_ignored_features <- function(design) {
  ignored <- character()
  probabilities <- tryCatch(as.numeric(design$prob), error = function(e) numeric())
  probabilities <- probabilities[is.finite(probabilities)]
  spread <- if (length(probabilities) > 1L) diff(range(probabilities)) else 0
  if (spread > 1e-8 * max(probabilities, 0)) {
    ignored <- c(ignored, "sampling weights")
  }
  units <- tryCatch(design$cluster[[1L]], error = function(e) NULL)
  if (!is.null(units) && anyDuplicated(units) > 0L) {
    ignored <- c(ignored, "clusters")
  }
  ignored
}

.ht_prepare_model <- function(model, data = NULL, context = "diagnostic", allow_grouped = TRUE) {
  if (inherits(data, "survey.design")) {
    if (!inherits(model, "formula")) {
      stop(
        "When supplying a survey design you must provide the model as a formula.",
        call. = FALSE
      )
    }
    fit <- .ht_survey_ols(model, data, context)
    return(list(
      model = fit$model,
      data = fit$data,
      grouped = FALSE,
      group_splits = NULL,
      group_keys = NULL,
      fit_factory = NULL,
      formula = model,
      engine = "lm",
      source = "survey"
    ))
  }

  if (inherits(model, "workflow")) {
    if (!requireNamespace("workflows", quietly = TRUE)) {
      stop("tidymodels workflow supplied but the workflows package is not installed.", call. = FALSE)
    }
    parsnip_fit <- workflows::extract_fit_parsnip(model)
    # The engine's fit names the variables as the workflow's preprocessing
    # made them, its response `..y` among them, so the data the workflow was
    # fitted to do not hold them and every test would refuse those data.
    engine_terms <- tryCatch(stats::terms(parsnip_fit$fit), error = function(e) NULL)
    if (!is.null(data) && !is.null(engine_terms)) {
      lacking <- setdiff(all.vars(engine_terms), names(data))
      if (length(lacking) > 0L) {
        stop(
          "A tidymodels workflow is tested on the fit of its engine, whose ",
          "variables are those the workflow's preprocessing made (it names the ",
          "response `..y`), and `data` lacks ", paste(lacking, collapse = ", "),
          ". Pass `data = NULL`, which tests the model frame of that fit.",
          call. = FALSE
        )
      }
    }
    # Without `data`, the data of the fit are the model frame of the engine's
    # fit (below), which holds its response and its predictors. Before 0.16.0
    # they were the predictors of the workflow's mold, which lack the
    # response: every test refused them, and runHeteroTests() returned the
    # Cook-Weisberg statistic, which ignored them, under the names asked for.
    return(.ht_prepare_model(parsnip_fit, data = data, context = context, allow_grouped = allow_grouped))
  }

  if (inherits(model, "model_fit")) {
    engine_fit <- model$fit
    if (inherits(engine_fit, c("lm", "glm"))) {
      data <- data %||% tryCatch(engine_fit$model, error = function(e) NULL)
      prep <- .ht_prepare_input_data(data, context)
      formula <- .ht_extract_formula(engine_fit)
      return(list(
        model = engine_fit,
        data = prep$data,
        grouped = prep$grouped && allow_grouped,
        group_splits = if (allow_grouped) prep$group_splits else NULL,
        group_keys = if (allow_grouped) prep$group_keys else NULL,
        fit_factory = if (!is.null(formula) && allow_grouped) {
          function(df) .ht_refit_group(engine_fit, df)
        } else {
          NULL
        },
        formula = formula,
        engine = class(engine_fit)[1],
        source = "parsnip"
      ))
    }
    stop("Unsupported parsnip engine for heteroscedasticity diagnostics.", call. = FALSE)
  }

  if (inherits(model, "formula")) {
    if (is.null(data)) {
      stop("`data` must be supplied when `model` is a formula.", call. = FALSE)
    }
    prep <- .ht_prepare_input_data(data, context)
    fit <- stats::lm(model, data = prep$data)
    return(list(
      model = fit,
      data = prep$data,
      grouped = prep$grouped && allow_grouped,
      group_splits = if (allow_grouped) prep$group_splits else NULL,
      group_keys = if (allow_grouped) prep$group_keys else NULL,
      fit_factory = if (allow_grouped) function(df) stats::lm(model, data = df) else NULL,
      formula = model,
      engine = "lm",
      source = "formula"
    ))
  }

  if (inherits(model, c("lm", "glm"))) {
    base_data <- data %||% tryCatch(model.frame(model), error = function(e) NULL)
    prep <- .ht_prepare_input_data(base_data, context)
    formula <- .ht_extract_formula(model)
    fit_factory <- if (!is.null(formula) && allow_grouped) {
      function(df) .ht_refit_group(model, df)
    } else {
      NULL
    }
    return(list(
      model = model,
      data = prep$data,
      grouped = prep$grouped && allow_grouped,
      group_splits = if (allow_grouped) prep$group_splits else NULL,
      group_keys = if (allow_grouped) prep$group_keys else NULL,
      fit_factory = fit_factory,
      formula = formula,
      engine = class(model)[1],
      source = "model"
    ))
  }

  stop("Unsupported model type for heteroscedasticity diagnostics; supply an 'lm'/'glm', formula, tidymodels workflow or parsnip model.", call. = FALSE)
}

.ht_decorate_result <- function(result, diagnostic_name, model, data, extras = list()) {
  if (!inherits(result, "htest")) {
    return(result)
  }

  if (!inherits(result, "hetero_test")) {
    class(result) <- c("hetero_test", class(result))
  }

  attr(result, "diagnostic") <- diagnostic_name %||% attr(result, "diagnostic") %||% NA_character_
  attr(result, "nobs") <- attr(result, "nobs") %||% tryCatch(stats::nobs(model), error = function(e) if (!is.null(data)) nrow(data) else NA_integer_)
  attr(result, "model") <- attr(result, "model") %||% model
  attr(result, "data_source") <- attr(result, "data_source") %||% if (!is.null(data)) class(data)[1] else NA_character_
  attr(result, "extras") <- utils::modifyList(attr(result, "extras") %||% list(), extras)
  result
}

.ht_failure_result <- function(diagnostic_name, model, data, message,
                              suggestions = character(), issue = NULL) {
  base <- structure(
    list(
      statistic = c(NA_real_),
      parameter = NA_real_,
      p.value = NA_real_,
      method = sprintf("%s (failed)", diagnostic_name),
      data.name = tryCatch(
        deparse(stats::formula(model)),
        error = function(e) "model"
      )
    ),
    class = "htest"
  )
  .ht_decorate_result(
    base,
    diagnostic_name = diagnostic_name,
    model = model,
    data = data,
    extras = list(
      status = "error",
      message = message,
      suggestions = suggestions,
      issue = issue
    )
  )
}

# One row per test. A result can carry two parameters (the degrees of freedom
# of an F statistic, or a degree of freedom and a number of replications) and
# several estimates. Passing those vectors to data.frame() recycled the row, so
# such a test appeared twice in the tidy output and twice in every table and
# plot built from it. The second parameter gets its own column, and an estimate
# is reported only when there is exactly one.
ht_tidy_single <- function(x) {
  element <- function(value, i) {
    if (length(value) >= i) unname(value[[i]]) else NA_real_
  }
  estimate <- x$estimate
  method <- x$method %||% NA_character_
  alternative <- x$alternative %||% NA_character_
  extras <- attr(x, "extras") %||% list()
  status <- extras$status %||% "ok"
  failure_message <- extras$message %||% NA_character_
  suggestion_text <- extras$suggestions %||% NA_character_
  data.frame(
    diagnostic = attr(x, "diagnostic") %||% names(x$statistic)[1L] %||% NA_character_,
    statistic = element(x$statistic, 1L),
    parameter = element(x$parameter, 1L),
    parameter2 = element(x$parameter, 2L),
    p.value = element(x$p.value, 1L),
    estimate = if (length(estimate) == 1L) unname(estimate[[1L]]) else NA_real_,
    alternative = alternative,
    method = method,
    nobs = attr(x, "nobs") %||% NA_integer_,
    status = status,
    message = failure_message,
    suggestions = if (length(suggestion_text) == 0L) {
      NA_character_
    } else if (length(suggestion_text) > 1L) {
      paste(unique(suggestion_text), collapse = "\n")
    } else {
      suggestion_text
    },
    stringsAsFactors = FALSE
  )
}

# broom methods ----------------------------------------------------------

#' @title Tidy heteroscedasticity test results
#' @name tidy.hetero_test
#' @description Methods that integrate heteroscedasticity diagnostics with the
#'   broom generics provided by the `generics` package (and re-exported by
#'   broom). They produce tidy data frames suited for downstream analysis.
#' @param x A heteroscedasticity diagnostic result or collection.
#' @param ... Additional arguments passed to methods.
#' @param data Optional data frame supplied to [generics::augment()].
#' @return A data frame (for `tidy` and `glance`) or an augmented data frame (for
#'   `augment`).
#' @examples
#' data(mtcars)
#' fit <- lm(mpg ~ wt + qsec, data = mtcars)
#' res <- runHeteroTests(fit, mtcars, tests = "white")
#' generics::tidy(res[[1]])
#' generics::tidy(res)
#' @export
#' @method tidy hetero_test
#' @importFrom generics tidy
#' @seealso [generics::tidy()], [generics::glance()], [generics::augment()]
tidy.hetero_test <- function(x, ...) {
  ht_tidy_single(x)
}

#' @export
#' @method glance hetero_test
#' @importFrom generics glance
glance.hetero_test <- function(x, ...) {
  tidied <- ht_tidy_single(x)
  data.frame(
    diagnostic = attr(x, "diagnostic") %||% NA_character_,
    statistic = tidied$statistic,
    parameter = tidied$parameter,
    parameter2 = tidied$parameter2,
    p.value = tidied$p.value,
    method = x$method %||% NA_character_,
    nobs = attr(x, "nobs") %||% NA_integer_,
    stringsAsFactors = FALSE
  )
}

#' @export
#' @method augment hetero_test
#' @importFrom generics augment
augment.hetero_test <- function(x, data = NULL, ...) {
  model <- attr(x, "model")
  if (is.null(model)) {
    stop("Augmenting heteroscedasticity diagnostics requires the fitted model to be available.", call. = FALSE)
  }
  data <- data %||% tryCatch(model$model, error = function(e) NULL)
  if (is.null(data)) {
    stop("Unable to recover the data used to fit the model. Supply it explicitly via `data=`.", call. = FALSE)
  }
  df <- as.data.frame(data)
  df$.fitted <- tryCatch(stats::fitted(model), error = function(e) rep(NA_real_, nrow(df)))
  df$.resid <- tryCatch(stats::residuals(model), error = function(e) rep(NA_real_, nrow(df)))
  df$.std.resid <- tryCatch(stats::rstandard(model), error = function(e) rep(NA_real_, nrow(df)))
  df$.diagnostic <- attr(x, "diagnostic") %||% NA_character_
  df
}

# collections ------------------------------------------------------------

#' @export
#' @method tidy hetero_test_suite
tidy.hetero_test_suite <- function(x, ...) {
  pieces <- lapply(x, function(res) {
    if (inherits(res, "hetero_test")) {
      ht_tidy_single(res)
    } else {
      NULL
    }
  })
  pieces <- Filter(Negate(is.null), pieces)
  if (length(pieces) == 0) {
    return(data.frame())
  }
  out <- do.call(rbind, pieces)
  rownames(out) <- NULL
  out
}

#' @export
#' @method glance hetero_test_suite
glance.hetero_test_suite <- function(x, ...) {
  tidy_res <- tidy.hetero_test_suite(x)
  if (nrow(tidy_res) == 0) {
    return(data.frame(n_diagnostics = 0L, any_significant = FALSE))
  }
  data.frame(
    n_diagnostics = nrow(tidy_res),
    any_significant = any(tidy_res$p.value < 0.05, na.rm = TRUE),
    min_p.value = min(tidy_res$p.value, na.rm = TRUE),
    max_p.value = max(tidy_res$p.value, na.rm = TRUE)
  )
}

#' @export
#' @method augment hetero_test_suite
augment.hetero_test_suite <- function(x, data = NULL, ...) {
  pieces <- lapply(x, function(res) {
    if (inherits(res, "hetero_test")) {
      augment.hetero_test(res, data = data, ...)
    } else {
      NULL
    }
  })
  pieces <- Filter(Negate(is.null), pieces)
  if (length(pieces) == 0) {
    return(data.frame())
  }
  out <- do.call(rbind, pieces)
  rownames(out) <- NULL
  out
}

# grouped ---------------------------------------------------------------

#' @export
#' @method tidy hetero_grouped_suite
tidy.hetero_grouped_suite <- function(x, ...) {
  keys <- attr(x, "group_keys")
  if (is.null(keys)) {
    return(data.frame())
  }
  group_frames <- vector("list", length(x))
  for (i in seq_along(x)) {
    diag_res <- x[[i]]
    if (!inherits(diag_res, "hetero_test_suite")) {
      next
    }
    tidy_res <- tidy.hetero_test_suite(diag_res)
    if (nrow(tidy_res) == 0) {
      next
    }
    key_row <- keys[rep(i, nrow(tidy_res)), , drop = FALSE]
    group_frames[[i]] <- cbind(as.data.frame(key_row), tidy_res, row.names = NULL)
  }
  group_frames <- Filter(Negate(is.null), group_frames)
  if (length(group_frames) == 0) {
    return(data.frame())
  }
  out <- do.call(rbind, group_frames)
  rownames(out) <- NULL
  out
}

# public interface ------------------------------------------------------

#' Run heteroscedasticity diagnostics on the data of a survey design
#'
#' A convenience wrapper that takes the data out of a
#' [survey::svydesign()] object, fits the model by ordinary least squares and
#' runs [runHeteroTests()]. **It does not use the sampling weights, strata or
#' clusters of the design**, and warns when the design has unequal weights or
#' clusters.
#'
#' The tests are the ones [runHeteroTests()] runs on any `lm`: they treat the
#' observations as an independent sample with equal weights. They hold their
#' level on survey data when the design can be ignored given the regressors,
#' that is when the chance of being sampled depends only on variables in the
#' model, and the sample has no clusters. When selection depends on the
#' response, or observations are clustered, they reject a model with constant
#' error variance far more often than their nominal level.
#'
#' The package has no design-based test of constant variance. Sampling weights
#' are not precision weights: they say how many population units an
#' observation stands for and nothing about its error variance. Passing them
#' to `lm(weights = )`, or testing a [survey::svyglm()] fit, makes the tests
#' examine residuals multiplied by the square roots of the weights, and a
#' homoscedastic model is then rejected whenever the weights vary with the
#' regressors. `svyglm` fits are refused for that reason.
#'
#' `inst/validation/survey-designs-size.R` measures all of this, together with
#' two design-based tests that were tried and not adopted because they reject
#' too often at the sample sizes examined.
#'
#' @param formula Model formula specifying the mean structure.
#' @param design A [survey::svydesign()] object. Only its data are used.
#' @param tests Character vector of diagnostic names forwarded to
#'   [runHeteroTests()]. Defaults to the White and Koenker tests, the default
#'   of [runHeteroTests()]; it was the White and the classical Breusch-Pagan
#'   tests up to 0.14.0.
#' @param ... Additional arguments passed to [runHeteroTests()].
#' @return A [`hetero_test_suite`] object containing the diagnostic results.
#'   Since 0.16.0 it carries `attr(, "model_origin") = "survey"`: the model is
#'   fitted here, so `summary()` shows its formula rather than its call.
#' @section Earlier versions:
#' Up to 0.12.0 this page described a survey-weighted fit. The weights did not
#' reach the fit, which was by ordinary least squares, as it is now, so the
#' reported values are unchanged.
#' @seealso [runHeteroTests()]
#' @export
#' @examples
#'
#' if (requireNamespace("survey", quietly = TRUE)) {
#'   library(survey)
#'   data(api)
#'   dstrata <- svydesign(id = ~1, strata = ~stype, weights = ~pw, data = apistrat)
#'   # Warns: the weights of this design are unequal and are not used.
#'   res <- runSurveyHeteroTests(api00 ~ api99 + ell, dstrata, tests = "white")
#'   generics::tidy(res)
#' }
runSurveyHeteroTests <- function(formula, design, tests = c("white", "koenker"), ...) {
  if (!requireNamespace("survey", quietly = TRUE)) {
    stop("The survey package must be installed to analyse survey designs.", call. = FALSE)
  }
  if (!inherits(formula, "formula")) {
    stop("`formula` must be a model formula when analysing survey designs.", call. = FALSE)
  }
  if (!inherits(design, "survey.design")) {
    stop("`design` must be a survey::svydesign() object describing the survey structure.", call. = FALSE)
  }
  fit <- .ht_survey_ols(formula, design, "runSurveyHeteroTests()")
  # The model is fitted here, so the suite says so (rsuite_mark_origin()).
  rsuite_mark_origin(
    runHeteroTests(fit$model, data = fit$data, tests = tests, use_cache = FALSE, ...),
    "survey"
  )
}
